package com.dice.weather.service;

import com.dice.weather.exception.WeatherServiceException;
import com.dice.weather.helper.AuthHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherService {

    @Value("${rapid.key}")
    private String RAPID_API_KEY;

    @Value("${rapid.host}")
    private String RAPID_API_HOST;

    @Autowired
    private AuthHelper authHelper;

    public String getForecastSummary(String city, String basicAuth) throws Exception {

        try {
            if (authHelper.authenticate(basicAuth)) {
                throw new WeatherServiceException("Invalid client id or password","WET-001", HttpStatus.BAD_REQUEST);
            }

            String url = "https://forecast9.p.rapidapi.com/rapidapi/forecast/"+city+"/summary/";
            return makeApiCall(url);
        }
        catch (WeatherServiceException e) {
            throw new WeatherServiceException("Internal error","WET-002", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch (Exception e){
            throw new Exception();
        }

    }

    public String getHourlyForecast(String city, String basicAuth) throws WeatherServiceException {
        if (authHelper.authenticate(basicAuth)) {
            throw new WeatherServiceException("Invalid client id or password","WET-001", HttpStatus.BAD_REQUEST);
        }

        String url = "https://forecast9.p.rapidapi.com/rapidapi/forecast/"+city+"/hourly/";
        return makeApiCall(url);
    }

    private String makeApiCall(String url) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-RapidAPI-Key", RAPID_API_KEY);
        headers.set("X-RapidAPI-Host", RAPID_API_HOST);

        HttpEntity<String> entity = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        return response.getBody();
    }
}
