package com.dice.weather.controller;

import com.dice.weather.exception.WeatherServiceException;
import com.dice.weather.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @GetMapping("/forecast-summary")
    public ResponseEntity<String> getForecastSummary(
            @RequestParam String city,
            @RequestHeader("Authorization") String basicAuth) {

        try {
            return new ResponseEntity<>(weatherService.getForecastSummary(city, basicAuth), HttpStatus.OK);
        } catch (WeatherServiceException e){
            return new ResponseEntity<>("Internal error", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getLocalizedMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/hourly-forecast")
    public ResponseEntity<String> getHourlyForecast(
            @RequestParam String city,
            @RequestHeader("Authorization") String basicAuth) {

        try {
            return new ResponseEntity<>(weatherService.getHourlyForecast(city,basicAuth), HttpStatus.OK);
        } catch (WeatherServiceException e){
            return new ResponseEntity<>("Internal error", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getLocalizedMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
